#ifndef UNTITLED_UTILS_H
#define UNTITLED_UTILS_H

#include <vector>
#include <string>

 void splitString(std::string p_string, std::vector<std::string> &result, char delim);

void usage();


#endif //UNTITLED_UTILS_H
